package exceptions;

public class ExceptionsSistema {

	/**
	 * Teste de Inicialização do Sistema com valor em Caixa inferio a 0 (Zero).
	 * @param valor
	 * 
	 * @throws IllegalArgumentException.
	 */
	public void testCaixaException(int valor) {
		if (valor < 0) {
			throw new IllegalArgumentException("Erro na inicializacao: Caixa nao pode ser inferior a 0");
		}
	}
	
	/**
	 * Teste de Inicialização do Sistema com valor da Taxa inferior a 0 (Zero).
	 * @param taxa
	 * 
	 * @throws IllegalArgumentException.
	 */
	public void testTaxaException(double taxa) {
		if (taxa < 0) {
			throw new IllegalArgumentException("Erro na inicializacao: Taxa nao pode ser inferior a 0");
		}
	}
}
