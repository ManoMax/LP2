package classes;

import java.util.ArrayList;

import controllers.ControllerAposta;

public class Financeiro {

	/**
	 * Valor destinado a Caixa em Centavos.
	 * Valor destinado a Premiação em Centavos.
	 * Taxa a ser Retirada para Caixa.
	 */
	private int valorCaixa;
	private int valorPremio;
	private double taxa;
	
	/**
	 * Representação de um Sistema Financeiro.
	 * Definido com um valor inicial para Caixa e Premio de 0,
	 * e uma taxa de lucro do sistema como parâmetro.
	 * 
	 * @param taxa
	 * 
	 * @author Gabriel Max
	 */
	public Financeiro(double taxa) {
		this.valorCaixa = 0;
		this.valorPremio = 0;
		this.taxa = taxa;
	}
	
	/**
	 * Computação de Valores.
	 * Soma dos valores de Apostas perdedores,
	 * e distribuição de valores para Caixa e para Prêmios.
	 * 
	 * @param array
	 */
	public void computarValores(ArrayList<ControllerAposta> array) {
		double fundos = 0;
		for (ControllerAposta a : array) {
			if (a.getVitoria() == false) {
				fundos += a.getQuantia();
			}
		}
		this.valorCaixa = (int) (fundos * this.taxa);
		this.valorPremio = (int) (fundos * (1 - this.taxa));
	}

	/**
	 * Get do Valor destinado a Caixa do Cenario.
	 * 
	 * @return representação em inteiro do valor destinado a Caixa do Cenário.
	 */
	public int getCaixaCenario() {
		return this.valorCaixa;
	}

	/**
	 * Get do Valor destinado a Premiação do Cenario.
	 * 
	 * @return representação em inteiro do valor destinado a Premiação do Cenário.
	 */
	public int getTotalRateioCenario() {
		return this.valorPremio;
	}

}
