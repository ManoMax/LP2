package classes;

import java.util.ArrayList;

import controllers.ControllerAposta;
import controllers.ControllerFinanceiro;

public class Cenario {
	
	/**
	 * Lista de Apostas no Cenário.
	 * Boolean de Cenário Aberto (true) ou Fechado (false).
	 * Descrição de Cenário.
	 * Numeração do Cenário Cadastrado.
	 * Ocorrencia do Evento.
	 * Controller do Sistema Financeiro.
	 */
	private ArrayList<ControllerAposta> apostas;
	private boolean aberto;
	private String descricao; // Evento
	private int numeracao;
	private Ocorrencia oc;
	private ControllerFinanceiro financia;
	
	/**
	 * Representação de um Cenário.
	 * Definidos com uma descrição, uma numeração e uma taxa de lucro do Sistema.
	 * Construção de Lista de Apostas, Abertura para Cadastros true,
	 * Ocorrencia Não Finalizada e Construção de Financias.
	 * 
	 * Com os seguintes Parâmetros:
	 * @param descricao
	 * @param num
	 * @param taxa
	 * 
	 * @author Gabriel Max
	 */
	public Cenario(String descricao, int num, double taxa) {
		this.descricao = descricao;
		this.apostas = new ArrayList<>();
		this.aberto = true;
		this.numeracao = num;
		this.oc = Ocorrencia.NFINALIZADO;
		this.financia = new ControllerFinanceiro(taxa);
	}
	
	/**
	 * Cadastramento de Apostas.
	 * 
	 * Com os seguintes Parâmetros:
	 * @param nome
	 * @param quantia
	 * @param previsao
	 */
	public void cadastraAposta(String nome, int quantia, String previsao) {
		if (this.aberto) {
			apostas.add(new ControllerAposta(nome, quantia, previsao));
		}
	}
	
	/**
	 * Exibição do Valor Total Da Aposta.
	 * 
	 * @return inteiro do valor total da aposta.
	 */
	public int valorTotalDaAposta() {
		double soma = 0;
		for (ControllerAposta a: apostas) {
			soma += a.getQuantia();
		}
		int num = (int) (soma);
		return num;
	}
	
	/**
	 * Exibição do Número de Apostas.
	 * 
	 * @return inteiro do número de Apostas.
	 */
	public int getTamanho() {
		return apostas.size();
	}

	/**
	 * Representação de todas as Apostas Cadastradas.
	 * No formato:
	 * "nome - quantia - previsao
	 *  nome2 - quantia2 - privasao2
	 *            ...
	 *  nomeN - quantiaN - previsaoN"
	 * 
	 * @return representação String de todas as Apostas Cadastradas.
	 */
	public String exibeApostas() {
		String saida = "";
		for (ControllerAposta a: apostas) {
			saida += a.toString() + "\n";
		}
		return saida;
	}

	/**
	 * Encerramento de Apostas do Cenário.
	 * Set da Ocorrencia do Cenário.
	 * Set de Resultados para todos as Apostas.
	 * Computação dos Valores.
	 * Bloqueio de Novas apostas.
	 * 
	 * @param ocorreu
	 * @param taxa
	 */
	public void fecharAposta(boolean ocorreu, double taxa) {
		if (ocorreu) {
			this.oc = Ocorrencia.OCORREU;
		} else {
			this.oc = Ocorrencia.NOCORREU;
		}
		
		for (ControllerAposta a: apostas) {
			if (a.getPrevisao().equals("N VAI ACONTECER") && !(ocorreu)) {
				a.setVitoria(true);
			} else if (a.getPrevisao().equals("VAI ACONTECER") && ocorreu) {
				a.setVitoria(true);
			} else {
				a.setVitoria(false);
			}
		}
		
		financia.computarValores(this.apostas);
		this.aberto = false;
	}
	
	/**
	 * Retorno de Apostas cadastradas.
	 * 
	 * @return lista de Controller de Apostas.
	 */
	public ArrayList<ControllerAposta> getApostas() {
		return this.apostas;
	}

	/**
	 * Representação do Cenário.
	 * No formato:
	 * "descricao - ocorrencia"
	 * 
	 * @return representação String de Cenário.
	 */
	@Override
	public String toString() {
		return this.descricao + " - " +
			   this.oc.getOcorrencia();
	}

	/**
	 * Get Numeração.
	 * 
	 * @return representação do tipo inteiro da numeração do Cenário Cadastrado.
	 */
	public int getNum() {
		return this.numeracao;
	}

	/**
	 * Get Valor Destinado a Caixa do Cenário.
	 * 
	 * @return representação no formato inteiro do valor destinado a Caixa.
	 */
	public int getCaixaCenario() {
		return financia.getCaixaCenario();
	}

	/**
	 * Get Total Rateio Cenario.
	 * 
	 * @return representação no formato inteiro do valor destinado a Premiação.
	 */
	public int getTotalRateioCenario() {
		return financia.getTotalRateioCenario();
	}

	/**
	 * Get da Abertura de Cadastros no Cenário.
	 * Aberto (true) ou Fechado (false).
	 * 
	 * @return representação em booleano da Abertura do Sistema de Cadastro de Apostas.
	 */
	public boolean getAberto() {
		return this.aberto;
	}
}
