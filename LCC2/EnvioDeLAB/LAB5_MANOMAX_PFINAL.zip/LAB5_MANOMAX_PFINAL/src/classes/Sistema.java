package classes;

import java.util.ArrayList;
import controllers.ControllerCenario;
import exceptions.ExceptionsAposta;
import exceptions.ExceptionsCenario;
import exceptions.ExceptionsSistema;

/**
 * 
 * @author Gabriel Max
 *
 */
public class Sistema {
	
	/**
	 * Lista de Cenários no Sistema.
	 * Taxa de Lucro para o Sistema.
	 * Valor em Caixa do Sistema.
	 * 
	 * Exceptions de Cenário, Sistema e Aposta.
	 */
	private ArrayList<ControllerCenario> cenarios;
	private double taxa;
	private int caixa;
	
	private ExceptionsCenario exC;
	private ExceptionsSistema exS;
	private ExceptionsAposta exA;
	
	/**
	 * Representação de um Sistema.
	 * Construção dos Exceptions, 2 presentes como verificação de Construção.
	 * Construção de Lista de Cenários.
	 * Definição de Caixa e Taxa no Sistema.
	 * 
	 * @param caixa
	 * @param taxa
	 */
	public Sistema(int caixa, double taxa) {
		this.exC = new ExceptionsCenario();
		this.exS = new ExceptionsSistema();
		this.exA = new ExceptionsAposta();
		exS.testCaixaException(caixa);
		exS.testTaxaException(taxa);
		this.cenarios = new ArrayList<>();
		this.caixa = caixa;
		this.taxa = taxa;
	}
	
	/**
	 * Cadastro de Cenário.
	 * Construidos e acrescentados a Lista.
	 * Possui Testes Exceptions.
	 * 
	 * @param descricao
	 * @return representação em inteiro da numeração do Cenário.
	 */
	public int cadastrarCenario(String descricao) {
		exC.testCadastroCenarioDescricaoVaziaOuNula(descricao);
		ControllerCenario cen = new ControllerCenario(descricao, cenarios.size()+1, this.taxa);
		cenarios.add(cen);
		return cen.getNum();
	}
	
	/**
	 * Cadastro de Apostas em um Cenário Especifico.
	 * Construção de uma Aposta e acrescentada na Lista Apostas no Cenário especifico.
	 * Possui Testes Exceptions.
	 * 
	 * @param cenario
	 * @param apostador
	 * @param valor
	 * @param previsao
	 */
	public void cadastrarAposta(int cenario, String apostador, int valor, String previsao) {
		exC.testCadastroDeCenarioInvalido(cenario, this.cenarios);
		exA.testApostadorNulo(apostador);
		exA.testValorAposta(valor);
		exA.testPrevisaoAposta(previsao);
		cenarios.get(cenario-1).cadastraAposta(apostador, valor, previsao);
	}
	
	/**
	 * Exibição de um Cenário Especifico.
	 * No formato:
	 * "numeração - descricao - ocorrencia"
	 * Possui Teste Exception.
	 * 
	 * @param cenario
	 * @return representação String de um cenário Específico.
	 */
	public String exibirCenario(int cenario) {
		exC.testConsultaCenarioInvalido(cenario, this.cenarios);
		return cenario + " - " + cenarios.get(cenario-1).toString();
	}
	
	/**
	 * Exibição de Todos os Cenários Cadastrados.
	 * No formato:
	 * "1 - descricao1 - ocorrencia1
	 *  2 - descricao2 - ocorrencia2
	 *             ...
	 *  N - descricaoN - ocorrenciaN"
	 * 
	 * @return represenção String de todos os Cenários Cadastrados.
	 */
	public String exibirCenarios() {
		String saida = "";
		for (ControllerCenario c : cenarios) {
			saida += c.getNum() + " - " + c.toString() + "\n";
		}
		return saida;
	}

	/**
	 * Exibição do Valor Total Da Aposta.
	 * Possui Teste Exception.
	 * 
	 * @param cenario
	 * @return inteiro do valor total da aposta.
	 */
	public int valorTotalDeApostas(int cenario) {
		exC.testConsultaValorTotalCenarioInvalido(cenario, this.cenarios);
		return cenarios.get(cenario-1).valorTotalDaAposta();
	}

	/**
	 * Exibição do Número de Apostas em um Cenário Específico.
	 * Possui Teste Exception.
	 * 
	 * @param cenario
	 * @return inteiro do número de Apostas em um Cenário Específico.
	 */
	public int totalDeApostas(int cenario) {
		exC.testConsultaTotalDeApostasCenarioInvalido(cenario, this.cenarios);
		return cenarios.get(cenario-1).getTamanho();
	}

	/**
	 * Representação de todas as Apostas Cadastradas em um Cenário específico.
	 * No formato:
	 * "nome - quantia - previsao
	 *  nome2 - quantia2 - privasao2
	 *            ...
	 *  nomeN - quantiaN - previsaoN"
	 * 
	 * @param cenario
	 * @return representação String de todas as Apostas Cadastradas em um Cenário específico.
	 */
	public String exibeApostas(int cenario) {
		exC.testExibeApostasCenarioInvalido(cenario, this.cenarios);
		return cenarios.get(cenario-1).exibeApostas();
	}

	/**
	 * Encerramento de Apostas do Cenário específico.
	 * Set da Ocorrencia do Cenário.
	 * Set de Resultados para todos as Apostas do Cenário.
	 * Computação dos Valores.
	 * Bloqueio de Novas apostas.
	 * Possui Testes Exceptions.
	 * 
	 * @param cenario
	 * @param ocorreu
	 */
	public void fecharAposta(int cenario, boolean ocorreu) {
		exC.testFecharApostaCenarioInvalido(cenario, this.cenarios);
		exC.testCanerioFechado(cenarios.get(cenario-1).getAberto());
		cenarios.get(cenario-1).fecharAposta(ocorreu, this.taxa);
		this.caixa += cenarios.get(cenario-1).getCaixaCenario();
	}

	/**
	 * Get Valor Destinado a Caixa de um Cenário específico.
	 * 
	 * @param cenario
	 * @return representação no formato inteiro do valor destinado a Caixa do Cenário.
	 */
	public int getCaixaCenario(int cenario) {
		exC.testGetCaixaCenarioInvalido(cenario, this.cenarios);
		exC.testGetCaixaCenarioAberto(cenarios.get(cenario-1).getAberto());
		return cenarios.get(cenario-1).getCaixaCenario();
	}

	/**
	 * Get Valor em Caixa do Sistema.
	 * 
	 * @return representação em inteiro do Valor em Caixa do Sistema.
	 */
	public int getCaixa() {
		return this.caixa;
	}

	/**
	 * Get Valor Destinado a Premiação de um Cenário específico.
	 * 
	 * @param cenario
	 * @return representação no formato inteiro do valor destinado a Premiação do Cenário.
	 */
	public int getTotalRateioCenario(int cenario) {
		exC.testGetTotalRateioInvalido(cenario, this.cenarios);
		exC.testGetTotalRateioAberto(cenarios.get(cenario-1).getAberto());
		return cenarios.get(cenario-1).getTotalRateioCenario();
	}
}
