package classesTest;

import static org.junit.Assert.*;

import org.junit.Test;

import classes.Sistema;

public class SistemaTestJUnit {

	private Sistema sis;
	
	// Construtor de Sistemas
	@Test (expected = IllegalArgumentException.class) 
	public void construtorSistemaCaixaNegativo() {
		sis = new Sistema(-1, 0.5);
	}

	@Test
	public void construtorSistemaCaixaZero() {
		sis = new Sistema(0, 0.5);
	}
	
	@Test (expected = IllegalArgumentException.class) 
	public void construtorSistemaTaxaNegativa() {
		sis = new Sistema(100, -2);
	}
	
	@Test 
	public void construtorSistemaTaxaZero() {
		sis = new Sistema(100, 0);
	}
	
	@Test
	public void construtorSistemaPositivo() {
		sis = new Sistema(100, 0.4);
	}
	
	// Cadastro de Cenários
	@Test (expected = IllegalArgumentException.class) 
	public void cadastrarCenarioDescricaoVazia() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("");
	}
	
	@Test (expected = NullPointerException.class) 
	public void cadastrarCenarioDescricaoNula() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario(null);
	}
	
	@Test
	public void cadastrarCenario() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("Esse Cenário será criado?");
	}

	@Test
	public void cadastrarMaisDeUmCenario() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("Esse Cenário será criado?");
		sis.cadastrarCenario("Esse Também?");
	}
	
	// Exibir Cenario
	@Test (expected = IllegalArgumentException.class) 
	public void exibirCenarioNegativo() {
		sis = new Sistema(100, 0.4);
		sis.exibirCenario(-1);
	}
	
	@Test (expected = IllegalArgumentException.class) 
	public void exibirCenarioZero() {
		sis = new Sistema(100, 0.4);
		sis.exibirCenario(0);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void exibirCenarioNaoCadastrado() {
		sis = new Sistema(100, 0.4);
		sis.exibirCenario(1);
	}
	
	@Test 
	public void exibirCenarioCadastrado() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("Esse é o Cenario de numeração 1?");
		sis.exibirCenario(1);
	}

	@Test 
	public void exibirMaisDeUmCenarioCadastrado() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("Esse é o Cenário de Numeração 1?");
		sis.cadastrarCenario("Se o primeiro foi criado, esse vai dar certo?");
		sis.exibirCenario(1);
		sis.exibirCenario(2);
	}

	// Busca de Valor em Caixa de um Cenário
	@Test (expected = IllegalArgumentException.class)
	public void getCaixaDeCenarioNegativo() {
		sis = new Sistema(100, 0.4);
		sis.getCaixaCenario(-1);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void getCaixaDeCenarioZero() {
		sis = new Sistema(100, 0.4);
		sis.getCaixaCenario(0);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getCaixaDeCenarioNaoCadastrado() {
		sis = new Sistema(100, 0.4);
		sis.getCaixaCenario(1);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void getCaixaDeCenarioCadastradoAberto() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("Criado para Funcionar?");
		sis.getCaixaCenario(1);
	}
	
	@Test
	public void getCaixaDeCenarioCadastradoFechadoSemDinheiro() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("Criado para Funcionar?");
		sis.fecharAposta(1, true);
		assertEquals(0, sis.getCaixaCenario(1));
	}
	
	@Test
	public void getCaixaDeCenarioCadastradoFechadoComDinheiro() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("Criado para Funcionar?");
		sis.cadastrarAposta(1, "Dead Pool", 4, "VAI ACONTECER");
		sis.cadastrarAposta(1, "Batman", 2000, "N VAI ACONTECER");
		sis.fecharAposta(1, true);
		assertEquals(800, sis.getCaixaCenario(1));
	}
	
	// Busca de Valor em Premiações de um Cenário
	@Test (expected = IllegalArgumentException.class)
	public void getRateioDeCenarioNegativo() {
		sis = new Sistema(100, 0.4);
		sis.getTotalRateioCenario(-1);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void getRateioDeCenarioZero() {
		sis = new Sistema(100, 0.4);
		sis.getTotalRateioCenario(0);
	}

	@Test (expected = IllegalArgumentException.class)
	public void getRateioDeCenarioNaoCadastrado() {
		sis = new Sistema(100, 0.4);
		sis.getTotalRateioCenario(1);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void getRateioDeCenarioCadastradoAberto() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("Criado para Funcionar?");
		sis.getTotalRateioCenario(1);
	}
	
	@Test
	public void getRateioDeCenarioCadastradoFechadoSemDinheiro() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("Criado para Funcionar?");
		sis.fecharAposta(1, true);
		assertEquals(0, sis.getTotalRateioCenario(1));
	}
	
	@Test
	public void getRateioDeCenarioCadastradoFechadoComDinheiro() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("Criado para Funcionar?");
		sis.cadastrarAposta(1, "Dead Pool", 4, "VAI ACONTECER");
		sis.cadastrarAposta(1, "Batman", 2000, "N VAI ACONTECER");
		sis.fecharAposta(1, true);
		assertEquals(1200, sis.getTotalRateioCenario(1));
	}

	// Busca de Valor Total em uma Aposta
	@Test (expected = IllegalArgumentException.class)
	public void valorTotalDeApostaDeCenarioNegativo() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Midia", 100, "VAI ACONTECER");
		
		sis.valorTotalDeApostas(-1);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void valorTotalDeApostaDeCenarioZero() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Midia", 100, "VAI ACONTECER");
		
		sis.valorTotalDeApostas(0);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void valorTotalDeApostaDeCenarioNaoCadastrado() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Midia", 100, "VAI ACONTECER");
		sis.valorTotalDeApostas(2);
	}
	
	@Test
	public void valorTotalDeApostaDeCenarioCadastrado() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Midia", 100, "VAI ACONTECER");
		
		assertEquals(100, sis.valorTotalDeApostas(1));
	}
	
	@Test
	public void valorTotalDeApostaDeCenarioPositivo() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Midia", 100, "VAI ACONTECER");
		
		assertEquals(100, sis.valorTotalDeApostas(1));
	}
	
	// Busca de Total de Apostas
	@Test (expected = IllegalArgumentException.class)
	public void buscaTotalDeApostaDeCenarioNegativo() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Midia", 100, "VAI ACONTECER");
		sis.valorTotalDeApostas(-1);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void buscaTotalDeApostaDeCenarioZero() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Midia", 100, "VAI ACONTECER");
		sis.valorTotalDeApostas(0);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void buscaTotalDeApostaDeCenarioNaoCadastrado() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Midia", 100, "VAI ACONTECER");
		sis.valorTotalDeApostas(2);
	}
	
	@Test
	public void buscaTotalDeApostaDeCenarioCadastrado() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Midia", 100, "VAI ACONTECER");
		
		assertEquals(100, sis.valorTotalDeApostas(1));
	}
	
	// Exibir Lista de Cenários
	@Test
	public void exibirComNenhumCenarioCadastrado() {
		sis = new Sistema(100, 0.4);
		assertEquals("", sis.exibirCenarios());	
	}
	
	@Test
	public void exibirComUmCenarioCadastrado() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("Vai dar Certo?");
		assertEquals("1 - Vai dar Certo? - Nao finalizado\n", sis.exibirCenarios());	
	}
	
	@Test
	public void exibirListaDeMaisDeUmCenarioCadastradoNaoFinalizado() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("Vai dar Certo?");
		sis.cadastrarCenario("Esse também?");
		assertEquals("1 - Vai dar Certo? - Nao finalizado\n" +
				     "2 - Esse também? - Nao finalizado\n", sis.exibirCenarios());	
	}
	
	@Test
	public void exibirListaDeMaisDeUmCenarioCadastradoFinalizado() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("Vai dar Certo?");
		sis.cadastrarCenario("Esse também?");
		assertEquals("1 - Vai dar Certo? - Nao finalizado\n" +
				     "2 - Esse também? - Nao finalizado\n", sis.exibirCenarios());
		
		sis.fecharAposta(1, true);
		assertEquals("1 - Vai dar Certo? - Finalizado (ocorreu)\n" +
			     "2 - Esse também? - Nao finalizado\n", sis.exibirCenarios());
		
		sis.fecharAposta(2, false);
		assertEquals("1 - Vai dar Certo? - Finalizado (ocorreu)\n" +
			     "2 - Esse também? - Finalizado (n ocorreu)\n", sis.exibirCenarios());
	}

	// Exibir Apostas
	@Test (expected = IllegalArgumentException.class)
	public void exibirApostasDeCenarioNegativo() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Midia", 100, "VAI ACONTECER");
		
		sis.exibeApostas(-1);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void exibirApostasDeCenarioZero() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Midia", 100, "VAI ACONTECER");
		
		sis.exibeApostas(0);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void exibirApostasDeCenarioNaoCadastrado() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Midia", 100, "VAI ACONTECER");
		
		sis.exibeApostas(2);
	}
	
	@Test
	public void exibirApostasDeCenarioComUmaApostaCadastrada() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Midia", 100, "VAI ACONTECER");
		
		assertEquals("Midia - 100 - VAI ACONTECER\n", sis.exibeApostas(1));
	}
	
	@Test
	public void exibirApostasDeCenarioComMaisUmaApostaCadastrada() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Midia", 100, "N VAI ACONTECER");
		sis.cadastrarAposta(1, "Samuel", 10000, "VAI ACONTECER");
		
		assertEquals("Midia - 100 - N VAI ACONTECER\n" +
					 "Samuel - 10000 - VAI ACONTECER\n", sis.exibeApostas(1));
	}

	// Cadastrar Apostas
	@Test (expected = IllegalArgumentException.class)
	public void cadastrarApostaComCenarioNegativo() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarAposta(-1, "Michel Temer", 1, "VAI ACONTECER");
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void cadastrarApostaComCenarioZero() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarAposta(0, "Bolsonaro", 10, "N VAI ACONTECER");
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void cadastrarApostaComCenarioNaoCadastrado() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarAposta(1, "Cidadão Brasileiro", 100, "VAI ACONTECER");
	}
	
	@Test
	public void cadastrarApostaComCenarioCadastrado() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("Vai pra Rua?");
		sis.cadastrarAposta(1, "Cidadão Brasileiro", 3, "VAI ACONTECER");
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void cadastrarApostaComApostadorVazio() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("Feito só pra Teste?");
		sis.cadastrarAposta(1, "", 100, "VAI ACONTECER");
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void cadastrarApostaComApostadorVazioTambem() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("Feito só pra Teste?");
		sis.cadastrarAposta(1, "  ", 100, "VAI ACONTECER");
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void cadastrarApostaComApostadorNulo() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("Feito só pra Teste?");
		sis.cadastrarAposta(1, null, 100, "VAI ACONTECER");
	}

	@Test (expected = IllegalArgumentException.class)
	public void cadastrarApostaDeValorNegativo() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Você sabe quem", -1000, "VAI ACONTECER");
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void cadastrarApostaDeValorZero() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Cidadão Brasileiro", 0, "N VAI ACONTECER");
	}

	@Test
	public void cadastrarApostaDeValorPositivo() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Ricão Burguês", 20000, "VAI ACONTECER");
	}

	@Test (expected = IllegalArgumentException.class)
	public void cadastrarApostaDePrevisaoVazia() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Midia", 100, "");
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void cadastrarApostaDePrevisaoNula() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Jogador de LOL", 100, null);
	}

	@Test (expected = IllegalArgumentException.class)
	public void cadastrarApostaDePrevisaoDeEspacos() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Midia", 100, "  ");
	}

	@Test
	public void cadastrarApostaDePrevisaoValida() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Programador Misterioso", 100000, "VAI ACONTECER");
	}

	// Fechar Apostas
	@Test (expected = IllegalArgumentException.class)
	public void fecharApostasComCenarioNegativo() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Cidadão Brasileiro", 10, "N VAI ACONTECER");
		
		sis.fecharAposta(-1, true);
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void fecharApostasComCenarioZero() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Cidadão Brasileiro", 10, "N VAI ACONTECER");
		
		sis.fecharAposta(0, true);
	}

	@Test (expected = IllegalArgumentException.class)
	public void fecharApostasComCenarioNaoCadastrado() {
		sis = new Sistema(100, 0.4);
		sis.fecharAposta(1, true);
	}
	
	@Test
	public void fecharApostasComCenarioCadastrado() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Cidadão Brasileiro", 100, "N VAI ACONTECER");
		
		sis.fecharAposta(1, true);
	}

	@Test (expected = IllegalArgumentException.class)
	public void fecharApostasJaFechadas() {
		sis = new Sistema(100, 0.4);
		sis.cadastrarCenario("The bomb has been planted?");
		sis.cadastrarAposta(1, "Cidadão Brasileiro", 0, "N VAI ACONTECER");
		
		sis.fecharAposta(1, true);
		sis.fecharAposta(1, true);
	}

	// Busca de Valor Caixa do Sistema
	@Test
	public void buscaDeValorCaixaPadrao() {
		sis = new Sistema(100, 0.4);
		assertEquals(100, sis.getCaixa());
	}
	
	@Test
	public void buscaDeValorCaixaComputado() {
		sis = new Sistema(100, 0.4);
		
		sis.cadastrarCenario("Brasil campeão 2018?");
		
		sis.cadastrarAposta(1, "Max", 120, "VAI ACONTECER");
		sis.cadastrarAposta(1, "Samuel", 7000, "N VAI ACONTECER");
		sis.cadastrarAposta(1, "Goku", 8001, "N VAI ACONTECER");
		
		sis.fecharAposta(1, true);
		
		assertEquals(6100, sis.getCaixa());
	}
}
