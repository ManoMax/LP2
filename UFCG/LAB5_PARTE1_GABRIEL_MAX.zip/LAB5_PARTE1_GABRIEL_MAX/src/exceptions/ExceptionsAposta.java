package exceptions;

public class ExceptionsAposta {

	/**
	 * Teste de Apostador Null ou Vazio.
	 * @param apostador
	 * 
	 * @throws IllegalArgumentException.
	 */
	public void testApostadorNulo(String apostador) {		
		boolean erro = true;
		
		if (apostador == "") {
			throw new IllegalArgumentException("Erro no cadastro de aposta: Apostador nao pode ser vazio ou nulo");
		}
		
		if (apostador == null) {
			throw new IllegalArgumentException("Erro no cadastro de aposta: Apostador nao pode ser vazio ou nulo");
		}
		for (int i = 0; i < apostador.length(); i++) {
			if (apostador.charAt(i) != ' ') {
				erro = false;
			}
		}
		
		if (erro) {
			throw new IllegalArgumentException("Erro no cadastro de aposta: Apostador nao pode ser vazio ou nulo");
		}
	}

	/**
	 * Teste de Valor de Aposta 0 ou Negativa.
	 * @param valor
	 * 
	 * @throws IllegalArgumentException.
	 */
	public void testValorAposta(int valor) {
		if (valor <= 0) {
			throw new IllegalArgumentException("Erro no cadastro de aposta: Valor nao pode ser menor ou igual a zero");
		}
	}
	
	/**
	 * Teste de Previsão Null ou Vazio.
	 * @param previsao
	 * 
	 * @throws IllegalArgumentException.
	 */
	public void testPrevisaoAposta(String previsao) {
		if (previsao == null) {
			throw new IllegalArgumentException("Erro no cadastro de aposta: Previsao nao pode ser vazia ou nula");
		}
		boolean erro = true;
		for (int i = 0; i < previsao.length(); i++) {
			if (previsao.charAt(i) != ' ') {
				erro = false;
			}
		}
		if (erro) {
			throw new IllegalArgumentException("Erro no cadastro de aposta: Previsao nao pode ser vazia ou nula");
		}
		if (!previsao.equals("N VAI ACONTECER") && !previsao.equals("VAI ACONTECER")) {
			throw new IllegalArgumentException("Erro no cadastro de aposta: Previsao invalida");
		}
	}
}
