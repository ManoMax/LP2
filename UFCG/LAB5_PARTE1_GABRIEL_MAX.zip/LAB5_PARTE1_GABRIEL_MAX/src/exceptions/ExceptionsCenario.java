package exceptions;

import java.util.ArrayList;

import controllers.ControllerCenario;

public class ExceptionsCenario {
	
	/**
	 * Teste de Consulta Total de Apostas com Cenario Invalido.
	 * @param cenario
	 * @param cenarios
	 * 
	 * @throws IllegalArgumentException.
	 */
	public void testConsultaTotalDeApostasCenarioInvalido(int cenario, ArrayList<ControllerCenario> cenarios) {
		if (cenario <= 0) {
			throw new IllegalArgumentException("Erro na consulta do total de apostas: Cenario invalido");
		} else if (cenario > cenarios.size()) {
			throw new IllegalArgumentException("Erro na consulta do total de apostas: Cenario nao cadastrado");
		}
	}
	
	
	/**
	 * Teste de Cadastro de Apostas com Cenario Invalido.
	 * @param cenario
	 * @param cenarios
	 * 
	 * @throws IllegalArgumentException.
	 */
	public void testCadastroDeCenarioInvalido(int cenario, ArrayList<ControllerCenario> cenarios) {
		if (cenario <= 0) {
			throw new IllegalArgumentException("Erro no cadastro de aposta: Cenario invalido");
		} else if (cenario > cenarios.size()) {
			throw new IllegalArgumentException("Erro no cadastro de aposta: Cenario nao cadastrado");
		}
	}

	
	/**
	 * Teste de Consulta Valor Total com Cenario Invalido.
	 * @param cenario
	 * @param cenarios
	 * 
	 * @throws IllegalArgumentException.
	 */
	public void testConsultaValorTotalCenarioInvalido(int cenario, ArrayList<ControllerCenario> cenarios) {
		if (cenario <= 0) {
			throw new IllegalArgumentException("Erro na consulta do valor total de apostas: Cenario invalido");
		} else if (cenario > cenarios.size()) {
			throw new IllegalArgumentException("Erro na consulta do valor total de apostas: Cenario nao cadastrado");
		}
	}

	
	/**
	 * Teste de Consulta Cenário com Cenario Invalido.
	 * @param cenario
	 * @param cenarios
	 * 
	 * @throws IllegalArgumentException.
	 */
	public void testConsultaCenarioInvalido(int cenario, ArrayList<ControllerCenario> cenarios) {
		if (cenario <= 0) {
			throw new IllegalArgumentException("Erro na consulta de cenario: Cenario invalido");
		} else if (cenario > cenarios.size()) {
			throw new IllegalArgumentException("Erro na consulta de cenario: Cenario nao cadastrado");
		}
	}

	
	/**
	 * Teste de Cadastro de Cenário com Descricao vazia ou Nula.
	 * @param descricao
	 * 
	 * @throws NullPointerException.
	 */
	public void testCadastroCenarioDescricaoVaziaOuNula(String descricao) {
		if (descricao == null) {
			throw new NullPointerException("Erro no cadastro de cenario: Descricao nao pode ser vazia");
		}
		
		boolean erro = true;
		for (int i = 0; i < descricao.length(); i++) {
			if (descricao.charAt(i) != ' ') {
				erro = false;
			}
		}
		
		if (erro) {
			throw new IllegalArgumentException("Erro no cadastro de cenario: Descricao nao pode ser vazia");
		}
	}
	
	
	/**
	 * Teste de Fechar Apostas com Cenario Invalido.
	 * @param cenario
	 * @param cenarios
	 * 
	 * @throws IllegalArgumentException.
	 */
	public void testFecharApostaCenarioInvalido(int cenario, ArrayList<ControllerCenario> cenarios) {
		if (cenario <= 0) {
			throw new IllegalArgumentException("Erro ao fechar aposta: Cenario invalido");
		} else if (cenario > cenarios.size()) {
			throw new IllegalArgumentException("Erro ao fechar aposta: Cenario nao cadastrado");
		}
	}

	
	/**
	 * Teste de Fechar Apostas com Cenario Fechado.
	 * @param cadeado
	 * 
	 * @throws IllegalArgumentException.
	 */
	public void testCanerioFechado(boolean cadeado) {
		if (!cadeado) {
			throw new IllegalArgumentException("Erro ao fechar aposta: Cenario ja esta fechado");
		}
		
	}

	
	/**
	 * Teste de Consulta Caixa do Cenário com Cenario Inválido.
	 * @param cenario
	 * @param cenarios
	 * 
	 * @throws IllegalArgumentException.
	 */
	public void testGetCaixaCenarioInvalido(int cenario, ArrayList<ControllerCenario> cenarios) {
		if (cenario <= 0) {
			throw new IllegalArgumentException("Erro na consulta do caixa do cenario: Cenario invalido");
		} else if (cenario > cenarios.size()) {
			throw new IllegalArgumentException("Erro na consulta do caixa do cenario: Cenario nao cadastrado");
		}
	}

	
	/**
	 * Teste de Consulta Caixa do Cenário com Cenario Aberto.
	 * @param cadeado
	 * 
	 * @throws IllegalArgumentException.
	 */
	public void testGetCaixaCenarioAberto(boolean cadeado) {
		if (cadeado) {
			throw new IllegalArgumentException("Erro na consulta do caixa do cenario: Cenario ainda esta aberto");
		}
	}

	
	/**
	 * Teste de Consulta Rateio do Cenário com Cenario Invalido.
	 * @param cenario
	 * @param cenarios
	 * 
	 * @throws IllegalArgumentException.
	 */
	public void testGetTotalRateioInvalido(int cenario, ArrayList<ControllerCenario> cenarios) {
		if (cenario <= 0) {
			throw new IllegalArgumentException("Erro na consulta do total de rateio do cenario: Cenario invalido");
		} else if (cenario > cenarios.size()) {
			throw new IllegalArgumentException("Erro na consulta do total de rateio do cenario: Cenario nao cadastrado");
		}
	}

	
	/**
	 * Teste de Consulta Rateio do Cenário com Cenario Aberto.
	 * @param cadeado
	 * 
	 * @throws IllegalArgumentException.
	 */
	public void testGetTotalRateioAberto(boolean cadeado) {
		if (cadeado) {
			throw new IllegalArgumentException("Erro na consulta do total de rateio do cenario: Cenario ainda esta aberto");
		}
	}

	/**
	 * Teste de Exibe Apostas com Cenario Invalido.
	 * @param cadeado
	 * 
	 * @throws IllegalArgumentException.
	 */
	public void testExibeApostasCenarioInvalido(int cenario, ArrayList<ControllerCenario> cenarios) {
		if (cenario <= 0) {
			throw new IllegalArgumentException("Erro no cadastro de aposta: Valor nao pode ser menor ou igual a zero");
		}
		if (cenario > cenarios.size()) {
			throw new IllegalArgumentException("Erro no cadastro de aposta: Valor nao pode ser menor ou igual a zero");
		}
	}
}
