package classesTest;

import classes.Sistema;

public class MainSistema {

	/**
	 * Linhas de Código para Teste de Saída.
	 * @param args
	 */
	public static void main(String[] args) {
		 
		Sistema sis;
		
		sis = new Sistema(100, 0.4);
		
		sis.cadastrarCenario("Brasil campeão 2018?");
		
		sis.cadastrarAposta(1, "Max", 120, "VAI ACONTECER");
		sis.cadastrarAposta(1, "Samuel", 7000, "N VAI ACONTECER");
		sis.cadastrarAposta(1, "Goku", 8001, "N VAI ACONTECER");
		
		sis.fecharAposta(1, true);
		
		System.out.println(sis.getCaixa());
		System.out.println(sis.getTotalRateioCenario(1));
	}

}
