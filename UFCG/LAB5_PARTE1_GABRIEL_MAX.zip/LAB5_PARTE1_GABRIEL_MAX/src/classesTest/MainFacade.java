package classesTest;

public class MainFacade {

	/**
	 * Main Representativa para Testes de Métodos e saídas do Sistema presente na Facade.
	 * 
	 * @param args
	 * 
	 * @author Gabriel Max
	 */
	public static void main(String[] args) {
		
		Facade fac = new Facade();
		
		// Inicializa Sistema.
		fac.inicializa(1000, 0.4);
		
		// Get Caixa.
		System.out.println(fac.getCaixa());
		
		// Cadastra Cenário.
		System.out.println(fac.cadastrarCenario("Esse Método Ficará Perfeito?"));

		// Cadastra Segundo Cenário.
		System.out.println(fac.cadastrarCenario("Esse também?"));
		
		// Exibir Cenário 1 e 2.
		System.out.println(fac.exibirCenario(1));
		System.out.println(fac.exibirCenario(2));
		
		// Exibir Cenários.
		System.out.println(fac.exibirCenarios());
		
		// Cadastrar Apostas.
		fac.cadastrarAposta(1, "Max", 1000, "VAI ACONTECER");
		fac.cadastrarAposta(1, "Lukas", 1000, "N VAI ACONTECER");
		fac.cadastrarAposta(1, "Zaca", 1000, "N VAI ACONTECER");
		
		fac.cadastrarAposta(2, "Max", 420, "VAI ACONTECER");
		fac.cadastrarAposta(2, "Proerd", 666, "N VAI ACONTECER");
		
		// Valor Total de Apostas.
		System.out.println(fac.valorTotalDeApostas(1));
		System.out.println(fac.valorTotalDeApostas(2));
		
		// Total de Apostas.
		System.out.println(fac.totalDeApostas(1));
		System.out.println(fac.totalDeApostas(2));
		
		// Exibe Apostas.
		System.out.println(fac.exibeApostas(1));
		System.out.println(fac.exibeApostas(2));
		
		// Fechar Apostas.
		fac.fecharAposta(1, true);
		fac.fecharAposta(2, true);
		
		// Get Caixa Cenário.
		System.out.println(fac.getCaixaCenario(1));
		System.out.println(fac.getCaixaCenario(2));
		
		// Get Total Rateio Cenário.
		System.out.println(fac.getTotalRateioCenario(1));
		System.out.println(fac.getTotalRateioCenario(2));
	}
}
