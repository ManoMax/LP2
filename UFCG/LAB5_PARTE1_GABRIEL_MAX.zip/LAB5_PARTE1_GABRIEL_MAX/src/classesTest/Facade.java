package classesTest;

import classes.Sistema;
import easyaccept.EasyAccept;

public class Facade {
	
	/**
	 * Sistema.
	 */
	private Sistema sis;
	
	/**
	 * Construtor da Facade.
	 * Sem parâmetros.
	 * 
	 * @author Gabriel Max
	 */
	public Facade() {
	}
	
	/**
	 * Inicializa Sistema.
	 * 
	 * @param centavos
	 * @param taxa
	 */
	public void inicializa(int centavos, double taxa) {
		this.sis = new Sistema(centavos, taxa);
	}
	
	/**
	 * Get do Valor Caixa do Sistema.
	 * 
	 * @return representação em inteiro do Valor Caixa do Sistema (Em centavos).
	 */
	public int getCaixa() {
		return sis.getCaixa();
	}

	/**
	 * Cadastrar Cenário.
	 * 
	 * @param descricao
	 * @return representação em inteiro da Numeração do Cenário.
	 */
	public int cadastrarCenario(String descricao) {
		return sis.cadastrarCenario(descricao);
	}
	
	/**
	 * Exibição de um Cenário Especifico.
	 * No formato:
	 * "numeração - descricao - ocorrencia"
	 * 
	 * @param cenario
	 * @return representação String de um cenário Específico.
	 */
	public String exibirCenario(int cenario) {
		return sis.exibirCenario(cenario);
	}
	
	/**
	 * Exibição de Todos os Cenários Cadastrados.
	 * No formato:
	 * "1 - descricao1 - ocorrencia1
	 *  2 - descricao2 - ocorrencia2
	 *             ...
	 *  N - descricaoN - ocorrenciaN"
	 * 
	 * @return represenção String de todos os Cenários Cadastrados.
	 */
	public String exibirCenarios() {
		return sis.exibirCenarios();
	}

	/**
	 * Cadastro de Apostas em um Cenário Especifico.
	 * Construção de uma Aposta e acrescentada na Lista Apostas no Cenário especifico.
	 * 
	 * @param cenario
	 * @param apostador
	 * @param valor
	 * @param previsao
	 */
	public void cadastrarAposta(int cenario, String apostador, int valor, String previsao) {
		sis.cadastrarAposta(cenario, apostador, valor, previsao);
	}

	/**
	 * Exibição do Valor Total Da Aposta.
	 * 
	 * @param cenario
	 * @return inteiro do valor total da aposta.
	 */
	public int valorTotalDeApostas(int cenario) {
		return sis.valorTotalDeApostas(cenario);
	}

	/**
	 * Exibição do Número de Apostas em um Cenário Específico.
	 * 
	 * @param cenario
	 * @return inteiro do número de Apostas em um Cenário Específico.
	 */
	public int totalDeApostas(int cenario) {
		return sis.totalDeApostas(cenario);
	}

	/**
	 * Representação de todas as Apostas Cadastradas em um Cenário específico.
	 * No formato:
	 * "nome - quantia - previsao
	 *  nome2 - quantia2 - privasao2
	 *            ...
	 *  nomeN - quantiaN - previsaoN"
	 * 
	 * @param cenario
	 * @return representação String de todas as Apostas Cadastradas em um Cenário específico.
	 */
	public String exibeApostas(int cenario) {
		return sis.exibeApostas(cenario);
	}
	
	/**
	 * Encerramento de Apostas do Cenário específico.
	 * Set da Ocorrencia do Cenário.
	 * Set de Resultados para todos as Apostas do Cenário.
	 * Computação dos Valores.
	 * Bloqueio de Novas apostas.
	 * 
	 * @param cenario
	 * @param ocorreu
	 */
	public void fecharAposta(int cenario, boolean ocorreu) {
		sis.fecharAposta(cenario, ocorreu);
	}

	/**
	 * Get Valor Destinado a Caixa de um Cenário específico.
	 * 
	 * @param cenario
	 * @return representação no formato inteiro do valor destinado a Caixa do Cenário.
	 */
	public int getCaixaCenario(int cenario) {
		return sis.getCaixaCenario(cenario);
	}

	/**
	 * Get Valor Destinado a Premiação de um Cenário específico.
	 * 
	 * @param cenario
	 * @return representação no formato inteiro do valor destinado a Premiação do Cenário.
	 */
	public int getTotalRateioCenario(int cenario) {
		return sis.getTotalRateioCenario(cenario);
	}
	
	/**
	 * Main para Efetuação de Testes EasyAccept.
	 * Total de 4 arquivos.txt para testes.
	 * Disponíveis na Pasta acceptand_test.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		args = new String[] {"classesTest.Facade", "acceptance_test/teste1.txt", 
												   "acceptance_test/teste2.txt", 
												   "acceptance_test/teste3.txt", 
												   "acceptance_test/teste4.txt"};
		EasyAccept.main(args);
	}
	
}
