package classes;

public class Aposta {
	
	/**
	 * Nome do Apostador.
	 * Quantia da Aposta em Centavos.
	 * Previsão de Aposta (N VAI ACONTECER ou VAI ACONTECER).
	 * Vitoria: Ganhou (true) ou Perdeu (false)
	 */
	private String nome;
	private int quantia;
	private String previsao;
	private boolean vitoria;
	
	/**
	 * Representação de um Aposta.
	 * Definidos com um nome, uma quantia de aposta e uma previsão.
	 * 
	 * Com os seguintes Parâmetros:
	 * @param nome
	 * @param quantia
	 * @param previsao
	 * 
	 * @author Gabriel Max
	 */
	public Aposta(String nome, int quantia, String previsao) {
		this.nome = nome;
		this.quantia = quantia;
		this.previsao = previsao;
	}
	
	/**
	 * Exibe uma Representação String de Aposta.
	 * No seguinte formato:
	 * "nome - quantia - previsao"
	 * 
	 * @return representação String de Aposta.
	 */
	@Override
	public String toString() {
		return this.nome + " - " +
			   this.quantia + " - " +
			   this.previsao;
	}

	/**
	 * Retorna a Quantia Apostada.
	 * 
	 * @return valor inteiro da Aposta.
	 */
	public int getQuantia() {
		return this.quantia;
	}

	/**
	 * Retorna a Previsão da Aposta.
	 * 
	 * @return representação String da Previsão de Aposta.
	 */
	public String getPrevisao() {
		return this.previsao;
	}
	
	/**
	 * Retorna um boolean do Resultado da Aposta.
	 * Ganhou (true) e Perdeu (false).
	 * 
	 * @return boolean do Resultado da Aposta.
	 */
	public boolean getVitoria() {
		return this.vitoria;
	}

	/**
	 * Set em boolean do Resultado da Aposta.
	 * Ganhou (true) e Perdeu (false).
	 * 
	 * @param resultado
	 */
	public void setVitoria(boolean resultado) {
		this.vitoria = resultado;
	}
	
}
