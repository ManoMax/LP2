package classes;

public enum Ocorrencia {
	/**
	 * 3 Possíveis Ocorrencias para todo Cenário.
	 */
	OCORREU("Finalizado (ocorreu)"),
	NOCORREU("Finalizado (n ocorreu)"),
	NFINALIZADO("Nao finalizado");

	/**
	 * Variável de modificação de Status.
	 */
	private String status;
	
	/**
	 * Construtor de Ocorrencia.
	 * e Set da Ocorrencia.
	 * 
	 * @param status
	 */
	private Ocorrencia(String status) {
		this.status = status;
	}
	
	/**
	 * Representação da Ocorrencia do Cenário.
	 * 
	 * @return representação String da Ocorrencia do Cenário.
	 */
	public String getOcorrencia() {
		return this.status;
	}
}
