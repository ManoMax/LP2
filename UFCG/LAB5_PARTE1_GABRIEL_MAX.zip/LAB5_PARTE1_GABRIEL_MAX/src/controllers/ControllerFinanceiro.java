package controllers;

import java.util.ArrayList;

import classes.Financeiro;

public class ControllerFinanceiro {
	
	/**
	 * Classe Financeiro presente para o Controller.
	 */
	private Financeiro financias;
	
	/**
	 * Construtor do Controller.
	 * Construção da classe Financeiro.
	 * 
	 * @param taxa
	 * 
	 * @author Gabriel Max
	 */
	public ControllerFinanceiro(double taxa) {
		financias = new Financeiro(taxa);
	}
	
	/**
	 * Computação de Valores.
	 * Soma dos valores de Apostas perdedores,
	 * e distribuição de valores para Caixa e para Prêmios.
	 * 
	 * @param array
	 */
	public void computarValores(ArrayList<ControllerAposta> array) {
		this.financias.computarValores(array);
	}
	
	/**
	 * Get do Valor destinado a Caixa do Cenario.
	 * 
	 * @return representação em inteiro do valor destinado a Caixa do Cenário.
	 */
	public int getCaixaCenario() {
		return this.financias.getCaixaCenario();
	}
	
	/**
	 * Get do Valor destinado a Premiação do Cenario.
	 * 
	 * @return representação em inteiro do valor destinado a Premiação do Cenário.
	 */
	public int getTotalRateioCenario() {
		return this.financias.getTotalRateioCenario();
	}
}
