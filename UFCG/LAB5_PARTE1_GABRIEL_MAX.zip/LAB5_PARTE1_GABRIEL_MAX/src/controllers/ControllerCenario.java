package controllers;

import java.util.ArrayList;

import classes.Cenario;


public class ControllerCenario {
	
	/**
	 * Classe Cenario presente para o Controller.
	 */
	private Cenario cont;
	
	/**
	 * Construtor do Controller.
	 * Construção da classe Cenario.
	 * 
	 * @param descricao
	 * @param num
	 * @param taxa
	 * 
	 * @author Gabriel Max
	 */
	public ControllerCenario(String descricao, int num, double taxa) {
		this.cont = new Cenario(descricao, num, taxa);
	}
	
	/**
	 * Cadastramento de Apostas.
	 * 
	 * Com os seguintes Parâmetros:
	 * @param nome
	 * @param quantia
	 * @param previsao
	 */
	public void cadastraAposta(String nome, int quantia, String previsao) {
		cont.cadastraAposta(nome, quantia, previsao);
	}
	
	/**
	 * Representação do Cenário.
	 * No formato:
	 * "descricao - ocorrencia"
	 * 
	 * @return representação String de Cenário.
	 */
	@Override
	public String toString() {
		return cont.toString();
	}

	/**
	 * Exibição do Valor Total Da Aposta.
	 * 
	 * @return inteiro do valor total da aposta.
	 */
	public int valorTotalDaAposta() {
		return cont.valorTotalDaAposta();
	}

	/**
	 * Exibição do Número de Apostas.
	 * 
	 * @return inteiro do número de Apostas.
	 */
	public int getTamanho() {
		return cont.getTamanho();
	}

	/**
	 * Representação de todas as Apostas Cadastradas.
	 * No formato:
	 * "nome - quantia - previsao
	 *  nome2 - quantia2 - privasao2
	 *            ...
	 *  nomeN - quantiaN - previsaoN"
	 * 
	 * @return representação String de todas as Apostas Cadastradas.
	 */
	public String exibeApostas() {
		return cont.exibeApostas();
	}

	/**
	 * Encerramento de Apostas do Cenário.
	 * Set da Ocorrencia do Cenário.
	 * Set de Resultados para todos as Apostas.
	 * Computação dos Valores.
	 * Bloqueio de Novas apostas.
	 * 
	 * @param ocorreu
	 * @param taxa
	 */
	public void fecharAposta(boolean ocorreu, double taxa) {
		cont.fecharAposta(ocorreu, taxa);
	}

	/**
	 * Retorno de Apostas cadastradas.
	 * 
	 * @return lista de Controller de Apostas.
	 */
	public ArrayList<ControllerAposta> getApostas() {
		return this.cont.getApostas();
	}

	/**
	 * Get Numeração.
	 * 
	 * @return representação do tipo inteiro da numeração do Cenário Cadastrado.
	 */
	public int getNum() {
		return cont.getNum();
	}

	/**
	 * Get Total Rateio Cenario.
	 * 
	 * @return representação no formato inteiro do valor destinado a Premiação.
	 */
	public int getTotalRateioCenario() {
		return cont.getTotalRateioCenario();
	}


	/**
	 * Get Valor Destinado a Caixa do Cenário.
	 * 
	 * @return representação no formato inteiro do valor destinado a Caixa.
	 */
	public int getCaixaCenario() {
		return cont.getCaixaCenario();
	}


	/**
	 * Get da Abertura de Cadastros no Cenário.
	 * Aberto (true) ou Fechado (false).
	 * 
	 * @return representação em booleano da Abertura do Sistema de Cadastro de Apostas.
	 */
	public boolean getAberto() {
		return cont.getAberto();
	}
}
