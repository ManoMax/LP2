package controllers;

import classes.Aposta;

public class ControllerAposta {

	/**
	 * Classe Aposta presente para o Controller.
	 */
	private Aposta aposta;
	
	/**
	 * Construtor do Controller.
	 * Construção da classe Aposta.
	 * 
	 * @param nome
	 * @param quantia
	 * @param previsao
	 * 
	 * @author Gabriel Max
	 */
	public ControllerAposta(String nome, int quantia, String previsao) {
		this.aposta = new Aposta(nome, quantia, previsao);
	}
	
	/**
	 * Exibe uma Representação String de Aposta.
	 * No seguinte formato:
	 * "nome - quantia - previsao"
	 * 
	 * @return representação String de Aposta.
	 */
	public String toString() {
		return this.aposta.toString();
	}
	
	/**
	 * Retorna a Quantia Apostada.
	 * 
	 * @return valor inteiro da Aposta.
	 */
	public double getQuantia() {
		return this.aposta.getQuantia();
	}
	
	/**
	 * Retorna um boolean do Resultado da Aposta.
	 * Ganhou (true) e Perdeu (false).
	 * 
	 * @return boolean do Resultado da Aposta.
	 */
	public boolean getVitoria() {
		return this.aposta.getVitoria();
	}
	
	/**
	 * Retorna a Previsão da Aposta.
	 * 
	 * @return representação String da Previsão de Aposta.
	 */
	public String getPrevisao() {
		return this.aposta.getPrevisao();
	}

	/**
	 * Set em boolean do Resultado da Aposta.
	 * Ganhou (true) e Perdeu (false).
	 * 
	 * @param resultado
	 */
	public void setVitoria(boolean resultado) {
		this.aposta.setVitoria(resultado);
	}
}
