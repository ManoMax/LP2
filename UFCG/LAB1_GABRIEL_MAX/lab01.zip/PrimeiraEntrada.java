/**
 * Laboratório de Programação 2 - Lab 1
 * 
 * @author Gabriel Max Vieira Matos - 117110060
 */

public class PrimeiraEntrada {
	public static void main(String[] angs) throws Exception {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Faz o Teste, Digite algo:");
		
		String nome = sc.nextLine();
		
		System.out.println(System.in.read());
	}
}
