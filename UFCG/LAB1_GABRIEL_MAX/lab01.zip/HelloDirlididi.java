/**
 * Laboratório de Programação 2 - Lab 1
 * 
 * @author Gabriel Max Vieira Matos - 117110060
 */

public class HelloDirlididi {
	public static void main(String[] angs) {
		System.out.println("Hello Dirlididi!");
	}
}
